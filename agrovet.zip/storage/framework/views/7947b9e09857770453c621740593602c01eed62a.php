<?php $__env->startSection('header'); ?>
    View Stocks
    <!--<small>Optional description</small>-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navigate'); ?>
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">View Stocks</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <!--<div class="box-header">
                    <h3 class="box-title">Data Table With Full Features</h3>
                </div>-->
                <!-- /.box-header -->
                <div class="box-body">
                    <?php echo $__env->make('messages.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Manufactured Date</th>
                            <th>Expiry Date</th>
                            <th>Date Stocked</th>
                            <th>Bought Price</th>
                            <th>Transport Cost</th>
                            <th>Modify</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if(count($stocks)>=1): ?>
                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td id="name">
                                        <?php echo e($stock->product_name); ?> <?php echo e($stock->manufacturer_name); ?> <?php echo e($stock->concentration); ?>

                                    </td>
                                    <td>
                                        <?php echo e($stock->quantity); ?>

                                    </td>
                                    <td>
                                        <?php echo e($stock->manufactured_date); ?>

                                    </td>
                                    <td>
                                        <?php echo e($stock->expiry_date); ?>

                                    </td>
                                    <td>
                                        <?php echo e($stock->date_stocked); ?>

                                    </td>
                                    <td>
                                        <?php echo e($stock->bought_price); ?>

                                    </td>
                                    <td>
                                        <?php echo e($stock->transport_cost); ?>

                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="/stock/edit/<?php echo e($stock->id); ?>" type="button" class="btn btn-warning btn-sm">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                            <button type="button" class="btn btn-danger btn-sm" data-toggle="modal"
                                                    value="/stock/delete/<?php echo e($stock->id); ?>"
                                                    data-target="#modal-danger" onclick="deleteStock(this.value)">
                                                <i class="fa fa-trash"></i> Delete
                                            </button>
                                            <a href="/stock/show/<?php echo e($stock->id); ?>" type="button" class="btn btn-info btn-sm">
                                                <i class="fa fa-info"></i> View
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="alert alert-info alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <h4><i class="icon fa fa-ban"></i> Alert!</h4>
                                No Products Added yet!
                            </div>
                        <?php endif; ?>
                        <tfoot>
                        <tr>
                            <th>Product Name</th>
                            <th>Quantity</th>
                            <th>Manufactured Date</th>
                            <th>Expiry Date</th>
                            <th>Date Stocked</th>
                            <th>Bought Price</th>
                            <th>Transport Cost</th>
                            <th>Modify</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>

                <?php $__env->startComponent('components.modals',[
                    'type' => 'danger',
                    'icon' => 'ban',
                    'title' => 'Delete Stock',
                    'ok_link' => "#",
                    'ok_text' => 'Yes',
                ]); ?>
                    <?php $__env->slot('body'); ?>
                        Are you sure you want to delete Stock <b><span id='stockName'></span></b> ?
                    <?php $__env->endSlot(); ?>

                <?php echo $__env->renderComponent(); ?>

                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
        <!-- /.col -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function () {
            $('#example1').DataTable();
            $('#example2').DataTable({
                'paging'      : true,
                'lengthChange': false,
                'searching'   : false,
                'ordering'    : true,
                'info'        : true,
                'autoWidth'   : false
            });
        });

        function deleteStock(value) {
            $('#ok_block').attr('href',value);
            var name = $('#name').text();
            $('#stockName').text(name);
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>