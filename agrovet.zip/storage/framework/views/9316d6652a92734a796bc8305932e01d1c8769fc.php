

<div class="form-group has-feedback<?php echo e($errors->has($name) ? ' has-error' : ''); ?>">
    <input type="<?php echo e($type); ?>" class="form-control" name="<?php echo e($name); ?>" value="<?php echo e(old($name)); ?>" placeholder="<?php echo e($placeholder); ?>">
    <span class="fa fa-<?php echo e($icon); ?> form-control-feedback"></span>
    <?php if($errors->has($name)): ?>
        <span class="invalid-feedback">
            <strong><?php echo e($errors->first($name)); ?></strong>
        </span>
    <?php endif; ?>
</div>