<?php $__env->startSection('navigate'); ?>
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Add Product</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <body class="hold-transition register-page">
    <style>
        .register-box
        {
            margin:0% auto;
        }
    </style>
    <div class="register-box">
        <div class="register-logo">
            <a href="/"><b>AGROVET</b></a>
        </div>

        <div class="register-box-body">
            <p class="login-box-msg">Add a new Product</p>
            <!--
            | Error / Success Messages will be reported here.
            -->
            <?php echo $__env->make('messages.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form action="/product/store" method="post">
                <?php echo e(csrf_field()); ?>

                <!------------------
                | Product Name field
                ------------------->
                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'product_name',
                    'placeholder' => 'Enter the Product Name',
                    'type' => 'text',
                    'icon' => 'industry'
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <!------------------
                | Manufacturer Name field
                ------------------->
                <?php $__env->startComponent('components.select',[
                    'errors' => $errors,
                    'name' => 'manufacturer_name',
                    'placeholder' => '-- Select the Manufacturer Name --',
                    'icon' => 'gears',
                    'datas' => $manufacturers,
                    'display' => 'manufacturer_name',
                    'value' => 'id'
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <!------------------
                | Type Name field
                ------------------->
                <?php $__env->startComponent('components.select',[
                    'errors' => $errors,
                    'name' => 'type_name',
                    'placeholder' => '-- Select the Product Type --',
                    'icon' => 'shopping-basket',
                    'datas' => $types,
                    'display' => 'type_name',
                    'value' => 'id'
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <!------------------
                | Product Name field
                ------------------->
                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'concentration',
                    'placeholder' => 'Enter the Product Concentration',
                    'type' => 'text',
                    'icon' => 'industry'
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <div class="row">
                    <!-- /.col -->
                    <div class="col-xs-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Add</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

        </div>
        <!-- /.form-box -->
    </div>
    <!-- /.register-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>