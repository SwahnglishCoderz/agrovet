<li class="dropdown user user-menu">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <img src="/img/avatar.png" class="user-image" alt="User Image">
        <span class="hidden-xs"><?php echo e(Sentinel::getUser()->first_name); ?> <?php echo e(Sentinel::getUser()->last_name); ?></span>
    </a>
    <ul class="dropdown-menu">
        <!-- User image -->
        <li class="user-header">
            <img src="/img/avatar.png" class="img-circle" alt="User Image">

            <p>
                <?php echo e(Sentinel::getUser()->first_name); ?> <?php echo e(Sentinel::getUser()->last_name); ?> - <?php echo e(Sentinel::getUser()->roles()->first()->name); ?>

                <small>Member since <?php echo e(Sentinel::getUser()->created_at); ?></small>
            </p>
        </li>
        <!-- Menu Body -->
        
        <!-- Menu Footer-->
        <li class="user-footer">
            <div class="pull-left">
                <a href="#" class="btn btn-default btn-flat">Profile</a>
            </div>
            <div class="pull-right">
                <form method="POST" action="/logout" id="logout-form">
                    <?php echo e(csrf_field()); ?>

                    <a href="#" class="btn btn-default btn-flat" onclick="document.getElementById('logout-form').submit()">Sign Out</a>
                </form>
            </div>
        </li>
    </ul>
</li>