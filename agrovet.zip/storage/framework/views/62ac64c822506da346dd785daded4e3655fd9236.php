<?php $__env->startSection('navigate'); ?>
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Add Stock</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <body class="hold-transition register-page">
    <style>
        .register-box
        {
            margin:0% auto;
        }
    </style>
    <div class="register-box">
        <div class="register-logo">
            <a href="/"><b>AGROVET</b></a>
        </div>

        <div class="register-box-body">
            <p class="login-box-msg">Add a new Stock</p>
            <!--
            | Error / Success Messages will be reported here.
            -->
            <?php echo $__env->make('messages.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form action="/stock/store" method="post">
                <?php echo e(csrf_field()); ?>

                <!------------------
                | Stock field
                ------------------->
                <!------------------
                | Product Name field
                ------------------->
                <?php $__env->startComponent('components.select',[
                    'errors' => $errors,
                    'name' => 'product_name',
                    'placeholder' => '-- Select the Product Name --',
                    'icon' => 'shopping-basket',
                    'display' => null
                ]); ?>
                    <?php $__env->slot('display_block'); ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>">
                                <?php echo e($product->product_name); ?> <?php echo e($product->manufacturer_name); ?> <?php echo e($product->concentration); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__env->endSlot(); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'quantity',
                    'placeholder' => 'Enter quantity',
                    'icon' => 'at',
                    'type' => 'text',
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'manufactured_date',
                    'placeholder' => 'Enter Date Manufactured (yyyy-mm-dd)',
                    'icon' => 'gears',
                    'type' => 'text',
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'expiry_date',
                    'placeholder' => 'Enter Expiry Date (yyyy-mm-dd)',
                    'icon' => 'calendar-o',
                    'type' => 'text',
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'date_stocked',
                    'placeholder' => 'Enter Date Stocked (yyyy-mm-dd)',
                    'icon' => 'calendar',
                    'type' => 'text',
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'bought_price',
                    'placeholder' => 'Enter Bought Price',
                    'icon' => 'dollar',
                    'type' => 'number',
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <?php $__env->startComponent('components.input',[
                    'errors' => $errors,
                    'name' => 'transport_cost',
                    'placeholder' => 'Enter Transportation Cost',
                    'icon' => 'truck',
                    'type' => 'number',
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <div class="row">
                    <!-- /.col -->
                    <div class="col-xs-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Add</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

        </div>
        <!-- /.form-box -->
    </div>
    <!-- /.register-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>