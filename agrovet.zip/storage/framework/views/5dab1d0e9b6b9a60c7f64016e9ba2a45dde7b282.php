<div class="modal modal-danger fade" id="modal-<?php echo e($type); ?>" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span></button>
                <h4 class="modal-title"><i class="fa fa-<?php echo e($icon); ?>"></i> <?php echo e($title); ?></h4>
            </div>
            <div class="modal-body">
                <?php echo e($body); ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Cancel</button>
                <a id="ok_block" href="<?php echo e($ok_link); ?>" type="button" class="btn btn-outline"><?php echo e($ok_text); ?></a>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>