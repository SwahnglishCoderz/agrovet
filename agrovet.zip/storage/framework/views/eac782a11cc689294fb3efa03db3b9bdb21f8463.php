<div class="form-group has-feedback<?php echo e($errors->has($name) ? ' has-error' : ''); ?>">
	<select class="form-control" name="<?php echo e($name); ?>">
		<option value="">-- <?php echo e($placeholder); ?> --</option>
        <?php if($display != null): ?>
            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data->$value); ?>">
                <?php echo e($data->$display); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php echo e($display_block); ?>

        <?php endif; ?>
	</select>
    
    <span class="fa fa-<?php echo e($icon); ?> form-control-feedback"></span>
    <?php if($errors->has($name)): ?>
        <span class="invalid-feedback">
            <strong><?php echo e($errors->first($name)); ?></strong>
        </span>
    <?php endif; ?>
</div>