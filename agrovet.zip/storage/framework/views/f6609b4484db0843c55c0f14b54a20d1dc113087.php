<?php $__env->startSection('navigate'); ?>
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Admin</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Hello I am the Admin.
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>