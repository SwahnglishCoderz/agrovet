<header class="main-header">

    <!-- Logo -->
    <a href="#" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>AGROVET</b></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>AGROVET</b></span>
    </a>

    <!-- Header Navbar -->
    <?php echo $__env->make('layouts.header.navigation.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>