
<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>AGROVET | Dashboard</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin.css')); ?>">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

    <!-- Main Header -->
    <?php echo $__env->make('layouts.header.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Left side column. contains the logo and sidebar -->
    <?php echo $__env->make('layouts.sidebar.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <?php echo $__env->make('layouts.content', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /.content-wrapper -->

    <!-- Main Footer -->
    <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
            Created with <i class="fa fa-heartbeat"></i> with AdminLTE and Laravel.
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2016 <a href="#">JuneX05 & Minchiey Codes</a>.</strong> All rights reserved.
    </footer>

    <!-- Add the sidebar's background. This div must be placed
    immediately after the control sidebar -->
    <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- REQUIRED JS SCRIPTS -->

<script type="text/javascript" src="<?php echo e(asset('js/admin.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/icheck.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<script>
    $(function () {
        $('input').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            radioClass: 'iradio_square-blue',
            //increaseArea: '20%' /* optional */
        });
    });

</script>



</body>
</html>