<?php $__env->startSection('navigate'); ?>
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Edit Type</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <body class="hold-transition register-page">
    <style>
        .register-box
        {
            margin:0% auto;
        }
    </style>
    <div class="register-box">
        <div class="register-logo">
            <a href="/"><b>AGROVET</b></a>
        </div>

        <div class="register-box-body">
            <p class="login-box-msg">Edit Type
                <b>
                    <?php echo e($type->type_name); ?>

                </b>
            </p>
            <!--
            | Error / Success Messages will be reported here.
            -->
            <?php echo $__env->make('messages.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form action="/type/update/<?php echo e($type->id); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <!------------------
                | Type Name field
                ------------------->
                <?php $__env->startComponent('components.input-edit',[
                    'errors' => $errors,
                    'name' => 'type_name',
                    'placeholder' => 'Enter the Type Name',
                    'type' => 'text',
                    'icon' => 'graducation-cap',
                    'data' => $type,
                ]); ?>
                <?php echo $__env->renderComponent(); ?>

                <div class="row">
                    <!-- /.col -->
                    <div class="col-xs-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Update</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

        </div>
        <!-- /.form-box -->
    </div>
    <!-- /.register-box -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>