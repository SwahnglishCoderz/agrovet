@extends ('layouts.master')

@section('navigate')
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Admin</li>
@endsection

@section('content')
    Hello I am the Admin.
@endsection