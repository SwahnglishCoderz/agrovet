@extends('layout.app')

@section('content')
    <div class="w3-display-container w3-blue" style="height:-webkit-fill-available">
        <div class="w3-display-middle">
            <div class="w3-card-4 w3-padding-32">

                <header class="w3-container w3-blue w3-center">
                    <h3>OPERATOR</h3>
                </header>

                <div>
                    Welcome home OPERATOR
                </div>
            </div>
        </div>
    </div>
@endsection