<div class="col-xs-8">
    <button type="submit" class="btn btn-primary btn-block btn-flat">{{$name}}</button>
</div>